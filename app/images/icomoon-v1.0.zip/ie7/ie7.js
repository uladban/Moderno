/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'icomoon\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-search': '&#xf002;',
		'icon-th-large': '&#xf009;',
		'icon-th-list': '&#xf00b;',
		'icon-map-marker': '&#xf041;',
		'icon-shopping-cart': '&#xf07a;',
		'icon-phone': '&#xf095;',
		'icon-sort': '&#xf0dc;',
		'icon-unsorted': '&#xf0dc;',
		'icon-sort-desc': '&#xf0dd;',
		'icon-sort-down': '&#xf0dd;',
		'icon-sort-asc': '&#xf0de;',
		'icon-sort-up': '&#xf0de;',
		'icon-bolt': '&#xf0e7;',
		'icon-flash': '&#xf0e7;',
		'icon-angle-right': '&#xf105;',
		'icon-location-arrow': '&#xf124;',
		'icon-sort-amount-asc': '&#xf160;',
		'icon-sort-amount-desc': '&#xf161;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
